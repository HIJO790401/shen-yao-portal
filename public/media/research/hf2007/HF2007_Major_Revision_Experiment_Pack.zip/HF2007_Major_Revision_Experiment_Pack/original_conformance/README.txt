ICAISG 2026 T0 Submission Pack
Author: Wen-Yao Hsu
Affiliation: Independent Researcher, Silent School Studio, Taichung, Taiwan
Paper: From Sample Safety to Path Legitimacy: T0 Admission Gating for Unauthorized Reasoning Transitions in LLM-Integrated Systems

CONTENTS
- ICAISG2026_T0_Path_Legitimacy_WenYao_Hsu.docx : editable conference-style manuscript
- ICAISG2026_T0_Path_Legitimacy_WenYao_Hsu.pdf  : rendered five-page manuscript
- figure1...figure5...png                              : manuscript figures
- experiment/t0_reference_experiment.py               : deterministic reproduction script
- experiment/experiment1_exhaustive_8_relation_truth_table.csv
- experiment/experiment2_misleading_label_variants.csv
- experiment/experiment_summary.json
- experiment/run_stdout.txt

EXPERIMENT BOUNDARY
The reported experiments are structural conformance tests over supplied eight-relation Boolean states. They validate the deterministic T0 gate semantics and its reference implementation. They do NOT measure natural-language relation extraction accuracy, model-specific jailbreak robustness, or end-to-end agent security. The paper states these limitations explicitly.

REPRODUCE
python experiment/t0_reference_experiment.py

CURRENT ARCHIVED RUN (2026-08-06)
- Exhaustive relation states: 256 (1 fully authorized, 255 structurally unauthorized)
- Full T0 unauthorized admission rate: 0%
- Full T0 valid pass rate: 100%
- Field-presence control unauthorized admission rate: 100%
- Single-relation ablation: 1/255 = 0.392% unauthorized admission per omitted relation
- Misleading-label variants: 64; field-presence admits 64/64, full T0 admits 0/64
- Pure Python median per-case gate cost in this archived rerun:
  random relation vectors ~0.080 us; all-valid full scan ~0.093 us; failure at final relation ~0.086 us.
  Excludes semantic extraction, LLM inference, retrieval, network I/O, tool execution, storage and human review.

FORMATTING NOTE
The ICAISG 2026 CFP requires an English full paper of at least five pages. The conference links to an official template; the environment could not retrieve the template binary, so the manuscript uses a clean IEEE-like two-column conference layout rather than claiming byte-for-byte template identity. Before final submission, if the official template becomes available, the content can be flowed into that exact template without changing the research claims.
