#!/usr/bin/env python3
"""Reproducible structural conformance experiments for the T0 admission gate.

Scope: deterministic relationship-legality logic only. This script does not call an LLM,
parse arbitrary natural language, execute tools, or claim end-to-end jailbreak robustness.
"""
from __future__ import annotations
import csv, itertools, json, random, statistics, time, platform, os
from pathlib import Path

SEED = 888
RELATIONS = [
    "definer_to_object",
    "theory_to_domain",
    "evidence_to_proposition",
    "cause_to_conclusion",
    "boundary_to_scope",
    "gap_to_stop",
    "output_to_authority",
    "result_to_responsibility",
]
OUT = Path(__file__).resolve().parent


def t0_gate(bits):
    return all(bits)


def presence_only(fields_present):
    return all(fields_present)


def gate_without(bits, ignored_idx):
    return all(v for i, v in enumerate(bits) if i != ignored_idx)


def exhaustive_truth_table():
    rows=[]
    for bits in itertools.product([0,1], repeat=8):
        truth=t0_gate(bits)
        fields=(1,)*8  # all labels syntactically present by design
        row={r:v for r,v in zip(RELATIONS,bits)}
        row.update({
            "authorized_ground_truth":int(truth),
            "field_presence_pass":int(presence_only(fields)),
            "t0_full_pass":int(t0_gate(bits)),
        })
        for i,name in enumerate(RELATIONS):
            row[f"t0_without_{name}"]=int(gate_without(bits,i))
        rows.append(row)
    return rows


def misleading_label_variants(n=64):
    rng=random.Random(SEED)
    labels=["claimed_authority","claimed_evidence","claimed_responsibility","claimed_scope",
            "named_source","named_domain","claimed_causal_bridge","claimed_output_role"]
    rows=[]
    for case_id in range(1,n+1):
        failed=rng.randrange(8)
        bits=[1]*8; bits[failed]=0
        row={"case_id":case_id,"failed_relation":RELATIONS[failed]}
        for lab in labels: row[lab]=1
        for r,v in zip(RELATIONS,bits): row[r]=v
        row["authorized_ground_truth"]=0
        row["field_presence_pass"]=1
        row["t0_full_pass"]=int(t0_gate(bits))
        rows.append(row)
    return rows


def rates(rows, pred_key):
    valid=[r for r in rows if r["authorized_ground_truth"]==1]
    invalid=[r for r in rows if r["authorized_ground_truth"]==0]
    valid_pass=sum(r[pred_key] for r in valid)/len(valid)
    unauth_admit=sum(r[pred_key] for r in invalid)/len(invalid)
    acc=sum(int(r[pred_key]==r["authorized_ground_truth"]) for r in rows)/len(rows)
    return {"valid_pass_rate":valid_pass,"false_stop_rate":1-valid_pass,
            "unauthorized_admission_rate":unauth_admit,"accuracy":acc}


def microbench(bits_list, runs=5):
    results=[]
    checksum=0
    for _ in range(runs):
        t0=time.perf_counter_ns()
        c=0
        for bits in bits_list:
            c += int(t0_gate(bits))
        elapsed=time.perf_counter_ns()-t0
        results.append(elapsed/len(bits_list))
        checksum=c
    return {"n_cases_per_run":len(bits_list),"runs":runs,
            "median_ns_per_case":statistics.median(results),
            "min_ns_per_case":min(results),"max_ns_per_case":max(results),
            "checksum":checksum,"all_runs_ns_per_case":results}


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def main():
    rows=exhaustive_truth_table()
    misleading=misleading_label_variants()
    write_csv(OUT/'experiment1_exhaustive_8_relation_truth_table.csv', rows)
    write_csv(OUT/'experiment2_misleading_label_variants.csv', misleading)

    summary={
        "experiment":"T0 relationship-legality structural conformance benchmark",
        "date":"2026-08-06",
        "seed":SEED,
        "scope_note":"Tests deterministic gate semantics over supplied structured relation states. It does not measure natural-language relation extraction or end-to-end jailbreak robustness.",
        "exhaustive_8_relation_states":{
            "n_cases":len(rows),"n_valid":1,"n_invalid":255,
            "field_presence":rates(rows,"field_presence_pass"),
            "t0_full":rates(rows,"t0_full_pass"),
            "single_relation_ablations":{}
        },
        "misleading_label_variants":{
            "n_cases":len(misleading),
            "field_presence_unauthorized_admission_rate":sum(r['field_presence_pass'] for r in misleading)/len(misleading),
            "t0_full_unauthorized_admission_rate":sum(r['t0_full_pass'] for r in misleading)/len(misleading)
        }
    }
    for name in RELATIONS:
        key=f"t0_without_{name}"
        summary["exhaustive_8_relation_states"]["single_relation_ablations"][name]=rates(rows,key)

    # Reproducible performance check: 1M cases per run.
    rng=random.Random(SEED)
    random_vecs=[tuple(rng.getrandbits(1) for _ in range(8)) for _ in range(1_000_000)]
    all_valid=[(1,)*8]*1_000_000
    last_fail=[(1,1,1,1,1,1,1,0)]*1_000_000
    summary["reference_gate_microbenchmark"]={
        "random_relation_vectors":microbench(random_vecs),
        "all_valid_full_scan":microbench(all_valid),
        "single_failure_at_last_relation":microbench(last_fail),
        "environment":{
            "python":platform.python_version(),"platform":platform.platform(),
            "logical_cpus_visible":os.cpu_count()
        },
        "note":"Pure Python in-process boolean gate; excludes semantic extraction, LLM inference, retrieval, network I/O, tool execution, storage, and human review."
    }
    with (OUT/'experiment_summary.json').open('w',encoding='utf-8') as f:
        json.dump(summary,f,indent=2,ensure_ascii=False)
    print(json.dumps(summary, indent=2, ensure_ascii=False))

if __name__=='__main__': main()
