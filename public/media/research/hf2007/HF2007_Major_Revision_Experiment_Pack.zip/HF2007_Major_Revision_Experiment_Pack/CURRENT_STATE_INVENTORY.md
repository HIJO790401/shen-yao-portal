# HF2007 Current-State Inventory (Frozen Before Final Convergence)

Inventory date: 2026-09-07 UTC

Source boundary applied: the HF2007 Drive folder, the official `uiuc-kang-lab/InjecAgent` repository, and the HF2007 ICAISG Gmail thread only. No unrelated project material was used.

## Original submission artifacts (preserved, not overwritten)

| Drive file | Drive ID | Local frozen SHA-256 |
|---|---|---|
| `HF2007-ICAISG 2026-Review Form.pdf` | `14bnobp4WNbxSjO8kRoR5FMIXzWmtC-S3` | `236d31a38d0da8bf625b8dc9173e661bffa4eb1b7e86efd702ce7ad012a85613` |
| `ICAISG2026_T0_Path_Legitimacy_WenYao_Hsu.docx` | `15uBPhlC3_0YAEGjs1vg6Z4uMTeCflqMI` | `b06373d3d1209d9aa5a843f2abc93792c902333150fc2e021b36564b0e3344a8` |
| `ICAISG2026_T0_Submission_Pack.zip` | `1w4lL3dyLyaHHvPKPdzWEZmHRrut4l9w6` | `f6dd7221cc64adf1b4492fea7875fbf32fdb3b9f58c0bde4cdea8b0bb2183a54` |

The folder also contains original native Google Docs/Sheets and an original PDF. Those originals remain in place.

## Pre-final major-revision artifacts (frozen; to be archived)

| Drive file | Drive ID | Local frozen SHA-256 |
|---|---|---|
| `HF2007_Major_Revision_HIGHLIGHTED.docx` | `1psnuT9BsV0PxYyrgQIInzogPpPfU_zft` | `91c05c3ed7003c08fa12b387269cc73a526261ebb491df9c64cddbef133e3afd` |
| `HF2007_Major_Revision_HIGHLIGHTED.pdf` | `1tc52BgR--0F06ohceVZFHYldu9dsreXB` | `c9d37626ed4182e072b5129c6233edd2518531f08fdcb8c370dd451d24746356` |
| `HF2007_Major_Revision_CLEAN.docx` | `1Y9viXhZBToVUuM28u1Q0EyTf_k7ppuK7` | `6e2a510175a11e9ac0d24a0fcebfb0aa5f65f30f20ceeeeaa37130513d4ed726` |
| `HF2007_Major_Revision_CLEAN.pdf` | `1LuCkdmAF5pH9WHdqzu3heXSByItNnUE9` | `a4daf6be8c206c0fb6220c630d26410a4002cafe1b7d642e13f56593034536a5` |
| `HF2007_Response_to_Reviewer.docx` | `123wDmSAtXDWhtfoD_bcZnaOTNOVNMk34` | `c5c1aec1194b12896d90346041cab16226fa4e5d4b62f724a90e2bf9b97b9ae6` |
| `HF2007_Response_to_Reviewer.pdf` | `12U8TUHARYqzgPMuq5hCng03l_rLDW9Gp` | `bf103877c1c31d6c9ac6d157d190926eead1fd0cc261425962cd53f182c4d8db` |
| `HF2007_Major_Revision_Experiment_Pack.zip` | `11BLqeJoV_Was9fVi3bw1CdfrQ4325RpV` | `e673c34311da0d25ea9932a79b28ed58a56d013278e880a77b266d2312100f82` |
| `HF2007_FINAL_QA_REPORT.txt` | `1r8CpmCI1GDqLKFcH1NnzvQHQhAieekQF` | `eca7c4a9328f68c014c366c72b769ffaa5364cd4ab643b114907b682e57deb85` |

## Frozen review requirements

The two-page reviewer form requests a real-input-to-relation-vector layer, relation-extraction and end-to-end results, a worked public case, corpus-based justification for the eight relations, Figure 4 repair, RQ/experiment alignment, correction of the Gap-to-Stop wording, and removal of evidential overstatement from the original structural tests.

The HF2007 ICAISG Gmail message (`ICAISG 2026-HF2007-Paper Need to Revise and Review Again`, 2026-09-07) requires submission by September 11 of (1) a revised manuscript with changes highlighted and (2) a point-by-point response letter. It also supplies three IJCTE citations, which are checked and incorporated only as adjacent-context references; they are not used as T0 evidence or relation ground truth.
