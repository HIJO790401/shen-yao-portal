# HF2007 InjecAgent Source Provenance

Extraction date (UTC): `2026-09-07T06:03:57Z`

Official repository: <https://github.com/uiuc-kang-lab/InjecAgent>

Pinned commit: [`f19c9f2c79a41046eb13c03c51a24c567a8ffa07`](https://github.com/uiuc-kang-lab/InjecAgent/commit/f19c9f2c79a41046eb13c03c51a24c567a8ffa07)

| Source file | Exact immutable URL | Git blob SHA | SHA-256 of downloaded bytes | Source size | Selected records |
|---|---|---|---|---:|---|
| `data/user_cases.jsonl` | <https://github.com/uiuc-kang-lab/InjecAgent/blob/f19c9f2c79a41046eb13c03c51a24c567a8ffa07/data/user_cases.jsonl> | `6f3dd74a29539ac36c1afec4455fdbfa7870fcb1` | `c840e2b00fdce68e7142d0970220522303d67b2530d6fb36ef1112448cdd8977` | 17 JSONL rows | rows 1-17 / indices 0-16; IDs U01-U17 |
| `data/test_cases_dh_base.json` | <https://github.com/uiuc-kang-lab/InjecAgent/blob/f19c9f2c79a41046eb13c03c51a24c567a8ffa07/data/test_cases_dh_base.json> | `976ad4e2108a553a3b885951e8eb119aa91f9445` | `0a8186468d21389af432e8c7b399ae42264d1b93a07b65c7a489468508604305` | 510 JSON records | rows 1-17 / indices 0-16; IDs DH01-DH17 |
| `data/test_cases_ds_base.json` | <https://github.com/uiuc-kang-lab/InjecAgent/blob/f19c9f2c79a41046eb13c03c51a24c567a8ffa07/data/test_cases_ds_base.json> | `16f82d8a34349182eba883871333e569bafc6b93` | `4daab35c62a3845e8b9400f4dca58b9c9f37e57cd33b2337552557fbb26282e9` | 544 JSON records | rows 1-17 / indices 0-16; IDs DS01-DS17 |

`prepare_raw_cases.py` verifies each downloaded file against its Git blob SHA before selecting records. `selected_case_manifest.csv` gives the source index and record SHA-256 for every selected case. `selected_raw_cases.jsonl` retains the actual user instruction, tool response/transition, user-authorized tool, proposed action, and target tools. It intentionally omits InjecAgent's attack-type and expected-achievement fields because those fields are not T0 relation ground truth.

The selected slice is deterministic and matched, not random. It includes all 17 published user cases, the first 17 direct-harm composites, and the first 17 data-stealing composites at the pinned commit.
