# HF2007 Major-Revision Experiment Pack

This pack replaces the pre-final synthetic case construction with a byte-verifiable run over actual InjecAgent source files pinned to one public commit. It preserves two independent evidence paths:

1. **Reference path:** raw cases + the HF2007 rubric + frozen manual decisions -> `reference_annotations.csv`.
2. **Prediction path:** raw-only structured cases + the isolated deterministic extractor -> `predicted_relations.csv`.

The two outputs meet only in `compare_reference_prediction.py`.

## Reproduce

Run from this directory with Python 3.10 or later:

```bash
python run_all.py
```

The run verifies the three Git blob SHAs, recreates the selected 51-case raw interface, assembles the manual reference file, makes it read-only for the extractor stage, runs the extractor in its normal and isolated environments, and recomputes comparison, Wilson intervals, coverage, and real-corpus ablation.

## Key outputs

- `reference_annotations.csv`: provenance-complete author annotations under `reference/REFERENCE_ANNOTATION_PROTOCOL.md`.
- `predicted_relations.csv`: deterministic extractor predictions.
- `results/metrics.json`: machine-readable results and Wilson 95% intervals.
- `results/relation_metrics.csv`: per-relation agreement and positive/negative coverage.
- `results/ablation_results.csv`: relation ablation on the selected real records.
- `results/cofailure_patterns.csv`: observed failure co-occurrence.
- `results/independence_audit.json`: source/input checks plus isolated extractor execution.
- `results/public_url_validation.json`: live commit/file fetch and blob-SHA validation.
- `results/error_analysis.csv`: disagreement rows; header-only for this run because no disagreements occurred.
- `SOURCE_PROVENANCE.md` and `selected_case_manifest.csv`: immutable URLs, SHAs, and selected row IDs.
- `SHA256SUMS.txt`: final archive manifest.

## Result boundary

The observed exact-vector and outcome agreement are 51/51 (100%; Wilson 95% 93.00%-100.00%). This slice contains only two reference vectors. Five relations receive negative coverage and co-fail in all 34 stopped transitions; three relations receive no negative coverage. The results therefore do **not** establish independent necessity, semantic extraction from arbitrary language, general prompt-injection immunity, or an empirically minimal eight-relation basis.
