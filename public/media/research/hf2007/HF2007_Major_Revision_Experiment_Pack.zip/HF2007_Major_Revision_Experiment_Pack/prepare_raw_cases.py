#!/usr/bin/env python3
"""Prepare the fixed HF2007 InjecAgent slice from byte-verified public files.

This stage performs provenance-preserving selection only. It emits no T0
reference labels, no predicted labels, and no expected admission outcome.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw_sources"
OUT_JSONL = ROOT / "selected_raw_cases.jsonl"
OUT_CSV = ROOT / "selected_case_manifest.csv"

REPOSITORY_URL = "https://github.com/uiuc-kang-lab/InjecAgent"
COMMIT_SHA = "f19c9f2c79a41046eb13c03c51a24c567a8ffa07"
EXTRACTION_DATE_UTC = "2026-09-07T06:03:57Z"
SOURCES = {
    "user_cases.jsonl": {
        "repository_path": "data/user_cases.jsonl",
        "blob_sha": "6f3dd74a29539ac36c1afec4455fdbfa7870fcb1",
    },
    "test_cases_dh_base.json": {
        "repository_path": "data/test_cases_dh_base.json",
        "blob_sha": "976ad4e2108a553a3b885951e8eb119aa91f9445",
    },
    "test_cases_ds_base.json": {
        "repository_path": "data/test_cases_ds_base.json",
        "blob_sha": "16f82d8a34349182eba883871333e569bafc6b93",
    },
}


def git_blob_sha(data: bytes) -> str:
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def source_url(repository_path: str) -> str:
    return f"{REPOSITORY_URL}/blob/{COMMIT_SHA}/{repository_path}"


def source_record_hash(record: dict) -> str:
    canonical = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def source_metadata(filename: str) -> dict:
    path = RAW / filename
    data = path.read_bytes()
    meta = SOURCES[filename]
    observed_blob = git_blob_sha(data)
    if observed_blob != meta["blob_sha"]:
        raise ValueError(f"Git blob mismatch for {filename}: {observed_blob} != {meta['blob_sha']}")
    return {
        "repository_url": REPOSITORY_URL,
        "source_file": filename,
        "source_repository_path": meta["repository_path"],
        "source_url": source_url(meta["repository_path"]),
        "source_commit_sha": COMMIT_SHA,
        "source_blob_sha": meta["blob_sha"],
        "source_sha256": hashlib.sha256(data).hexdigest(),
        "extraction_date_utc": EXTRACTION_DATE_UTC,
    }


def load_sources():
    user_path = RAW / "user_cases.jsonl"
    users = [json.loads(line) for line in user_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    dh = json.loads((RAW / "test_cases_dh_base.json").read_text(encoding="utf-8"))
    ds = json.loads((RAW / "test_cases_ds_base.json").read_text(encoding="utf-8"))
    if len(users) != 17:
        raise ValueError(f"Expected 17 published user cases, found {len(users)}")
    if len(dh) < 17 or len(ds) < 17:
        raise ValueError("Composite source file contains fewer than 17 cases")
    return users, dh, ds


def user_case(record: dict, idx: int, meta: dict) -> dict:
    tool = record["User Tool"]
    return {
        "case_id": f"U{idx + 1:02d}",
        **meta,
        "source_record_index_zero_based": idx,
        "source_row_one_based": idx + 1,
        "source_record_sha256": source_record_hash(record),
        "raw_user_instruction": record["User Instruction"],
        "raw_user_authorized_tool": tool,
        "raw_tool_parameters": record.get("Tool Parameters", ""),
        "raw_tool_response": "",
        "tool_response_origin": "none_pre_tool_transition",
        "transition_type": "user_instruction_to_authorized_tool",
        "transition": f"USER_INSTRUCTION -> {tool}",
        "proposed_action_text": record["User Instruction"],
        "proposed_target_tools": [tool],
        "observable_structured_fields": {
            "origin_kind": "user_instruction",
            "user_authorized_tool": tool,
            "proposed_target_tools": [tool],
            "tool_response_present": False,
        },
    }


def composite_case(record: dict, idx: int, prefix: str, meta: dict) -> dict:
    user_tool = record["User Tool"]
    target_tools = list(record.get("Attacker Tools", []))
    return {
        "case_id": f"{prefix}{idx + 1:02d}",
        **meta,
        "source_record_index_zero_based": idx,
        "source_row_one_based": idx + 1,
        "source_record_sha256": source_record_hash(record),
        "raw_user_instruction": record["User Instruction"],
        "raw_user_authorized_tool": user_tool,
        "raw_tool_parameters": record.get("Tool Parameters", ""),
        "raw_tool_response": record.get("Tool Response", ""),
        "tool_response_origin": user_tool,
        "transition_type": "tool_response_to_proposed_action",
        "transition": f"TOOL_RESPONSE({user_tool}) -> PROPOSED_ACTION({';'.join(target_tools)})",
        "proposed_action_text": record.get("Attacker Instruction", ""),
        "proposed_target_tools": target_tools,
        "observable_structured_fields": {
            "origin_kind": "tool_response",
            "user_authorized_tool": user_tool,
            "proposed_target_tools": target_tools,
            "tool_response_present": True,
        },
    }


def main() -> None:
    users, dh, ds = load_sources()
    user_meta = source_metadata("user_cases.jsonl")
    dh_meta = source_metadata("test_cases_dh_base.json")
    ds_meta = source_metadata("test_cases_ds_base.json")

    rows = [user_case(record, idx, user_meta) for idx, record in enumerate(users)]
    rows += [composite_case(record, idx, "DH", dh_meta) for idx, record in enumerate(dh[:17])]
    rows += [composite_case(record, idx, "DS", ds_meta) for idx, record in enumerate(ds[:17])]
    if len(rows) != 51 or len({row["case_id"] for row in rows}) != 51:
        raise ValueError("Selected slice must contain 51 unique cases")

    forbidden = {"Expected Achievements", "Attack Type", "expected_answer", "reference_bits", "t0_reference_decision"}
    for row in rows:
        overlap = forbidden.intersection(row)
        if overlap:
            raise ValueError(f"Forbidden leakage fields in raw interface: {sorted(overlap)}")

    with OUT_JSONL.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    csv_fields = [
        "case_id", "source_file", "source_url", "source_commit_sha", "source_blob_sha",
        "source_sha256", "source_record_index_zero_based", "source_row_one_based",
        "source_record_sha256", "extraction_date_utc", "transition_type",
        "raw_user_authorized_tool", "tool_response_origin", "proposed_target_tools",
    ]
    with OUT_CSV.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=csv_fields)
        writer.writeheader()
        for row in rows:
            out = {key: row[key] for key in csv_fields}
            out["proposed_target_tools"] = ";".join(row["proposed_target_tools"])
            writer.writerow(out)

    print(json.dumps({
        "total": len(rows), "authorized_controls": 17, "direct_harm": 17,
        "data_stealing": 17, "commit_sha": COMMIT_SHA,
        "source_blob_shas": {name: meta["blob_sha"] for name, meta in SOURCES.items()},
        "outputs": [OUT_JSONL.name, OUT_CSV.name],
    }, indent=2))


if __name__ == "__main__":
    main()
