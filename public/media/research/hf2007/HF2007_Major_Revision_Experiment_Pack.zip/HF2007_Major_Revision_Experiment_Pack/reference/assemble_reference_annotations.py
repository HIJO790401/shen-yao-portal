#!/usr/bin/env python3
"""Join frozen manual decisions to raw HF2007 provenance without inferring labels.

The relation bits are copied verbatim from reference_decisions.csv. This
program only validates and joins them to the previously selected raw records.
It does not import, call, or replicate the extractor.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_CASES = ROOT / "selected_raw_cases.jsonl"
DECISIONS = Path(__file__).resolve().parent / "reference_decisions.csv"
OUTPUT = ROOT / "reference_annotations.csv"

RELATIONS = [
    "definer_to_object",
    "theory_to_domain",
    "evidence_to_proposition",
    "cause_to_conclusion",
    "boundary_to_scope",
    "gap_to_stop",
    "output_to_authority",
    "result_to_responsibility",
]


def main() -> None:
    raw_rows = [json.loads(line) for line in RAW_CASES.read_text(encoding="utf-8").splitlines() if line]
    with DECISIONS.open(newline="", encoding="utf-8") as stream:
        decisions = list(csv.DictReader(stream))
    raw_by_id = {row["case_id"]: row for row in raw_rows}
    dec_by_id = {row["case_id"]: row for row in decisions}
    if len(raw_by_id) != 51 or len(dec_by_id) != 51:
        raise ValueError("Reference assembly requires 51 unique raw cases and 51 unique decisions")
    if set(raw_by_id) != set(dec_by_id):
        raise ValueError("Raw/reference case-ID sets differ")

    output_rows = []
    for raw in raw_rows:
        dec = dec_by_id[raw["case_id"]]
        bits = []
        for relation in RELATIONS:
            value = dec[relation]
            if value not in {"0", "1"}:
                raise ValueError(f"Non-binary reference value for {raw['case_id']} {relation}: {value}")
            bits.append(int(value))
        expected_decision = "PASS" if all(bits) else "STOP_0_REVIEW"
        if dec["t0_reference_decision"] != expected_decision:
            raise ValueError(f"Reference decision inconsistent for {raw['case_id']}")
        output_rows.append({
            "case_id": raw["case_id"],
            "source_file": raw["source_file"],
            "source_url": raw["source_url"],
            "source_commit_sha": raw["source_commit_sha"],
            "source_sha": raw["source_blob_sha"],
            "source_sha256": raw["source_sha256"],
            "source_record_index_zero_based": raw["source_record_index_zero_based"],
            "source_row_one_based": raw["source_row_one_based"],
            "source_record_sha256": raw["source_record_sha256"],
            "extraction_date_utc": raw["extraction_date_utc"],
            "raw_user_instruction": raw["raw_user_instruction"],
            "raw_user_authorized_tool": raw["raw_user_authorized_tool"],
            "raw_tool_response": raw["raw_tool_response"],
            "tool_response_origin": raw["tool_response_origin"],
            "transition": raw["transition"],
            "transition_type": raw["transition_type"],
            "proposed_action_text": raw["proposed_action_text"],
            "proposed_target_tools": ";".join(raw["proposed_target_tools"]),
            **{relation: bits[index] for index, relation in enumerate(RELATIONS)},
            "relation_vector": "".join(str(bit) for bit in bits),
            "t0_reference_decision": dec["t0_reference_decision"],
            "annotation_rationale": dec["annotation_rationale"],
            "annotation_protocol": "HF2007_REFERENCE_PROTOCOL_v2",
        })

    with OUTPUT.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)
    print(json.dumps({"output": str(OUTPUT), "rows": len(output_rows), "label_source": str(DECISIONS)}, indent=2))


if __name__ == "__main__":
    main()
