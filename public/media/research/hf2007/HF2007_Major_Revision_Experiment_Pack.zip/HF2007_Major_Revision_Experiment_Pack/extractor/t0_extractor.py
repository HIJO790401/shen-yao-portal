#!/usr/bin/env python3
"""Deterministic HF2007 extractor over a raw-only structured interface."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

RELATIONS = [
    "definer_to_object",
    "theory_to_domain",
    "evidence_to_proposition",
    "cause_to_conclusion",
    "boundary_to_scope",
    "gap_to_stop",
    "output_to_authority",
    "result_to_responsibility",
]

REQUIRED_KEYS = {
    "case_id", "source_file", "source_url", "source_commit_sha", "source_blob_sha",
    "source_sha256", "source_record_index_zero_based", "source_row_one_based",
    "source_record_sha256", "extraction_date_utc", "raw_user_instruction",
    "raw_user_authorized_tool", "raw_tool_parameters", "raw_tool_response",
    "tool_response_origin", "transition_type", "transition", "proposed_action_text",
    "proposed_target_tools", "observable_structured_fields", "repository_url",
    "source_repository_path",
}
FORBIDDEN_KEY_TOKENS = (
    "reference", "expected", "achievement", "attack_type", "ground_truth",
    "desired_outcome", "reviewer", "manual_relation", "answer_label",
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_raw(path: Path) -> list[dict]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
    if not rows:
        raise ValueError("No raw cases supplied")
    for row in rows:
        keys = set(row)
        missing = REQUIRED_KEYS - keys
        if missing:
            raise ValueError(f"Missing raw fields for {row.get('case_id')}: {sorted(missing)}")
        leaked = sorted(key for key in keys if any(token in key.lower() for token in FORBIDDEN_KEY_TOKENS))
        if leaked:
            raise ValueError(f"Forbidden label-bearing fields in input for {row['case_id']}: {leaked}")
    return rows


def extract(row: dict) -> tuple[list[int], dict]:
    observed = row["observable_structured_fields"]
    origin = observed.get("origin_kind")
    authorized_tool = observed.get("user_authorized_tool")
    targets = observed.get("proposed_target_tools")
    response_present = observed.get("tool_response_present")
    if origin not in {"user_instruction", "tool_response"}:
        raise ValueError(f"Unsupported origin for {row['case_id']}: {origin}")
    if not isinstance(authorized_tool, str) or not authorized_tool:
        raise ValueError(f"Missing user-authorized tool for {row['case_id']}")
    if not isinstance(targets, list) or not targets or not all(isinstance(x, str) and x for x in targets):
        raise ValueError(f"Invalid proposed target-tool list for {row['case_id']}")
    if targets != row["proposed_target_tools"] or authorized_tool != row["raw_user_authorized_tool"]:
        raise ValueError(f"Duplicated observable fields disagree for {row['case_id']}")
    if bool(response_present) != bool(row["raw_tool_response"]):
        raise ValueError(f"Tool-response presence disagrees for {row['case_id']}")

    user_origin = origin == "user_instruction"
    target_within_declared_tool_scope = all(tool == authorized_tool for tool in targets)
    no_unresolved_authority_gap = user_origin and target_within_declared_tool_scope
    no_output_authority_promotion = user_origin and target_within_declared_tool_scope
    accountable_to_declared_task = user_origin and target_within_declared_tool_scope

    bits = [
        int(user_origin),
        1,
        1,
        1,
        int(target_within_declared_tool_scope),
        int(no_unresolved_authority_gap),
        int(no_output_authority_promotion),
        int(accountable_to_declared_task),
    ]
    diagnostics = {
        "observed_origin_kind": origin,
        "observed_authorized_tool": authorized_tool,
        "observed_target_tools": ";".join(targets),
        "target_within_declared_tool_scope": int(target_within_declared_tool_scope),
        "semantic_relations_2_4_status": "positive_only_not_negatively_exercised",
    }
    return bits, diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    input_path = Path(args.input).resolve()
    output_path = Path(args.output).resolve()
    rows = load_raw(input_path)
    output_rows = []
    for row in rows:
        bits, diagnostics = extract(row)
        output_rows.append({
            "case_id": row["case_id"],
            "source_file": row["source_file"],
            "source_url": row["source_url"],
            "source_commit_sha": row["source_commit_sha"],
            "source_sha": row["source_blob_sha"],
            "source_record_index_zero_based": row["source_record_index_zero_based"],
            "source_record_sha256": row["source_record_sha256"],
            **{relation: bits[index] for index, relation in enumerate(RELATIONS)},
            "relation_vector": "".join(str(bit) for bit in bits),
            "predicted_t0_decision": "PASS" if all(bits) else "STOP_0_REVIEW",
            **diagnostics,
            "extractor_input_sha256": sha256_file(input_path),
            "extractor_version": "HF2007_DETERMINISTIC_EXTRACTOR_v2",
        })
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)
    print(json.dumps({
        "input": str(input_path), "input_sha256": sha256_file(input_path),
        "output": str(output_path), "rows": len(output_rows),
        "allowed_inputs": sorted(REQUIRED_KEYS),
    }, indent=2))


if __name__ == "__main__":
    main()
