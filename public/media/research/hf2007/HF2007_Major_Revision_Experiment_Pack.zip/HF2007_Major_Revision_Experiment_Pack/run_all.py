#!/usr/bin/env python3
"""Reproduce the HF2007 independent annotation/extraction comparison."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*parts: str) -> None:
    completed = subprocess.run([sys.executable, *parts], cwd=ROOT, check=False)
    if completed.returncode:
        raise SystemExit(completed.returncode)


def main() -> None:
    run("prepare_raw_cases.py")
    reference = ROOT / "reference_annotations.csv"
    if reference.exists():
        reference.chmod(0o644)
    run("reference/assemble_reference_annotations.py")
    reference.chmod(0o444)
    run(
        "extractor/t0_extractor.py",
        "--input", "selected_raw_cases.jsonl",
        "--output", "predicted_relations.csv",
    )
    run("audit_independence.py")
    run("compare_reference_prediction.py")

    metrics = json.loads((ROOT / "results" / "metrics.json").read_text(encoding="utf-8"))
    audit = json.loads((ROOT / "results" / "independence_audit.json").read_text(encoding="utf-8"))
    isolated_hash = audit["isolated_execution"]["output_sha256"]
    primary_hash = sha256(ROOT / "predicted_relations.csv")
    if audit["status"] != "PASS" or isolated_hash != primary_hash:
        raise SystemExit("Extractor independence/reproducibility audit failed")
    if metrics["dataset"]["total"] != 51:
        raise SystemExit("Unexpected case count")
    summary = {
        "status": "PASS",
        "cases": 51,
        "exact_vector_matches": metrics["exact_vector_match"]["count"],
        "outcome_matches": metrics["t0_outcome_agreement"]["count"],
        "independence_audit": audit["status"],
        "predicted_relations_sha256": primary_hash,
        "python_version": platform.python_version(),
        "source_commit_sha": metrics["dataset"]["source_commit_sha"],
    }
    (ROOT / "results" / "reproduction_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
