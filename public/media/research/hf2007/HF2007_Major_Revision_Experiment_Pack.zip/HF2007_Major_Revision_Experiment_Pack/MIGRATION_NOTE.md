# Pre-final Experiment Replacement

The pre-final major-revision experiment constructed 17 user-tool rows and two injected families inside the same Python program that also held the reference relation vectors. That arrangement did not satisfy the final independence requirement and is not used here.

This final pack instead:

- includes the actual three InjecAgent source files at a pinned commit;
- verifies their Git blob SHAs before selecting rows;
- emits a label-free raw interface;
- stores manual reference decisions in a separate frozen file;
- runs the extractor without reference files or label-bearing fields;
- compares the outputs only afterward; and
- reports the observed agreement, coverage, co-failure, and ablation without tuning for a desired score.

The original submission's Boolean/conformance code is preserved under `original_conformance/` only for historical reproducibility. It is not empirical evidence for relation necessity or end-to-end admission performance.
