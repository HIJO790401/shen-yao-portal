#!/usr/bin/env python3
"""Compare independently frozen HF2007 references with extractor predictions."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "reference_annotations.csv"
PREDICTION = ROOT / "predicted_relations.csv"
RESULTS = ROOT / "results"
RELATIONS = [
    "definer_to_object", "theory_to_domain", "evidence_to_proposition",
    "cause_to_conclusion", "boundary_to_scope", "gap_to_stop",
    "output_to_authority", "result_to_responsibility",
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> list[float] | None:
    if total == 0:
        return None
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return [max(0.0, center - half), min(1.0, center + half)]


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    if fieldnames is None:
        fieldnames = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def t0(bits: list[int]) -> str:
    return "PASS" if all(bits) else "STOP_0_REVIEW"


def pct(value: float) -> str:
    return f"{100 * value:.2f}%"


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    refs = read_csv(REFERENCE)
    preds = read_csv(PREDICTION)
    ref_by_id = {row["case_id"]: row for row in refs}
    pred_by_id = {row["case_id"]: row for row in preds}
    if len(ref_by_id) != len(refs) or len(pred_by_id) != len(preds):
        raise ValueError("Duplicate case IDs")
    if set(ref_by_id) != set(pred_by_id):
        raise ValueError("Reference and prediction case-ID sets differ")

    comparison = []
    errors = []
    for case_id in [row["case_id"] for row in refs]:
        ref = ref_by_id[case_id]
        pred = pred_by_id[case_id]
        for key in ["source_file", "source_url", "source_commit_sha", "source_sha", "source_record_index_zero_based", "source_record_sha256"]:
            if ref[key] != pred[key]:
                raise ValueError(f"Provenance mismatch for {case_id}: {key}")
        ref_bits = [int(ref[relation]) for relation in RELATIONS]
        pred_bits = [int(pred[relation]) for relation in RELATIONS]
        relation_matches = [int(a == b) for a, b in zip(ref_bits, pred_bits)]
        exact = int(all(relation_matches))
        outcome_match = int(ref["t0_reference_decision"] == pred["predicted_t0_decision"])
        row = {
            "case_id": case_id,
            "source_file": ref["source_file"],
            "source_record_index_zero_based": ref["source_record_index_zero_based"],
            "source_record_sha256": ref["source_record_sha256"],
            "reference_vector": ref["relation_vector"],
            "predicted_vector": pred["relation_vector"],
            "exact_vector_match": exact,
            "reference_decision": ref["t0_reference_decision"],
            "predicted_decision": pred["predicted_t0_decision"],
            "outcome_match": outcome_match,
        }
        for relation, match in zip(RELATIONS, relation_matches):
            row[f"match_{relation}"] = match
        comparison.append(row)
        if not exact or not outcome_match:
            errors.append(row)

    n = len(comparison)
    relation_metrics = {}
    relation_rows = []
    for relation in RELATIONS:
        ref_values = [int(ref_by_id[row["case_id"]][relation]) for row in comparison]
        pred_values = [int(pred_by_id[row["case_id"]][relation]) for row in comparison]
        tp = sum(r == 1 and p == 1 for r, p in zip(ref_values, pred_values))
        tn = sum(r == 0 and p == 0 for r, p in zip(ref_values, pred_values))
        fp = sum(r == 0 and p == 1 for r, p in zip(ref_values, pred_values))
        fn = sum(r == 1 and p == 0 for r, p in zip(ref_values, pred_values))
        agreement = tp + tn
        positives = sum(ref_values)
        negatives = n - positives
        metrics = {
            "n": n,
            "reference_positive": positives,
            "reference_negative": negatives,
            "prediction_positive": sum(pred_values),
            "prediction_negative": n - sum(pred_values),
            "tp": tp, "tn": tn, "fp": fp, "fn": fn,
            "agreement_count": agreement,
            "agreement_rate": agreement / n,
            "agreement_wilson95": wilson(agreement, n),
            "positive_state_agreement": tp / positives if positives else None,
            "positive_state_agreement_wilson95": wilson(tp, positives),
            "negative_state_agreement": tn / negatives if negatives else None,
            "negative_state_agreement_wilson95": wilson(tn, negatives),
            "has_positive_coverage": positives > 0,
            "has_negative_coverage": negatives > 0,
        }
        relation_metrics[relation] = metrics
        relation_rows.append({"relation": relation, **metrics})

    exact_count = sum(row["exact_vector_match"] for row in comparison)
    outcome_count = sum(row["outcome_match"] for row in comparison)
    reference_pass = [row for row in comparison if row["reference_decision"] == "PASS"]
    reference_stop = [row for row in comparison if row["reference_decision"] == "STOP_0_REVIEW"]
    false_stops = sum(row["predicted_decision"] != "PASS" for row in reference_pass)
    false_admissions = sum(row["predicted_decision"] == "PASS" for row in reference_stop)

    # Real-corpus ablation: remove one relation by forcing that reference bit to 1.
    ablation_rows = []
    for relation_index, relation in enumerate(RELATIONS):
        unauthorized_admissions = 0
        authorized_passes = 0
        for case_id in ref_by_id:
            ref = ref_by_id[case_id]
            bits = [int(ref[name]) for name in RELATIONS]
            bits[relation_index] = 1
            outcome = t0(bits)
            if ref["t0_reference_decision"] == "STOP_0_REVIEW":
                unauthorized_admissions += outcome == "PASS"
            else:
                authorized_passes += outcome == "PASS"
        ablation_rows.append({
            "removed_relation": relation,
            "reference_negative_coverage": relation_metrics[relation]["reference_negative"],
            "unauthorized_admissions": unauthorized_admissions,
            "unauthorized_total": len(reference_stop),
            "unauthorized_admission_rate": unauthorized_admissions / len(reference_stop),
            "unauthorized_admission_wilson95": json.dumps(wilson(unauthorized_admissions, len(reference_stop))),
            "authorized_passes": authorized_passes,
            "authorized_total": len(reference_pass),
            "independent_necessity_established": "NO",
        })

    exercised = [name for name in RELATIONS if relation_metrics[name]["reference_negative"] > 0]
    joint_admissions = 0
    for ref in refs:
        if ref["t0_reference_decision"] != "STOP_0_REVIEW":
            continue
        bits = [int(ref[name]) for name in RELATIONS]
        for name in exercised:
            bits[RELATIONS.index(name)] = 1
        joint_admissions += t0(bits) == "PASS"

    failure_patterns = Counter(
        ";".join(name for name in RELATIONS if int(ref[name]) == 0) or "NONE"
        for ref in refs
    )
    cofailure_rows = [{"failed_relations": pattern, "case_count": count} for pattern, count in sorted(failure_patterns.items())]

    metrics = {
        "experiment": "HF2007 independent reference-versus-extractor comparison",
        "dataset": {
            "total": n,
            "reference_pass": len(reference_pass),
            "reference_stop": len(reference_stop),
            "source_commit_sha": refs[0]["source_commit_sha"],
            "source_blob_shas": sorted({row["source_sha"] for row in refs}),
            "unique_reference_vectors": dict(Counter(row["relation_vector"] for row in refs)),
            "unique_predicted_vectors": dict(Counter(row["relation_vector"] for row in preds)),
        },
        "artifact_hashes": {
            "reference_annotations_sha256": digest(REFERENCE),
            "predicted_relations_sha256": digest(PREDICTION),
            "selected_raw_cases_sha256": digest(ROOT / "selected_raw_cases.jsonl"),
            "extractor_source_sha256": digest(ROOT / "extractor" / "t0_extractor.py"),
        },
        "exact_vector_match": {
            "count": exact_count, "total": n, "rate": exact_count / n,
            "wilson95": wilson(exact_count, n),
        },
        "t0_outcome_agreement": {
            "count": outcome_count, "total": n, "rate": outcome_count / n,
            "wilson95": wilson(outcome_count, n),
        },
        "end_to_end": {
            "authorized_passes": len(reference_pass) - false_stops,
            "authorized_total": len(reference_pass),
            "false_stops": false_stops,
            "false_stop_rate": false_stops / len(reference_pass),
            "false_stop_rate_wilson95": wilson(false_stops, len(reference_pass)),
            "attack_stops": len(reference_stop) - false_admissions,
            "attack_total": len(reference_stop),
            "false_admissions": false_admissions,
            "false_admission_rate": false_admissions / len(reference_stop),
            "false_admission_rate_wilson95": wilson(false_admissions, len(reference_stop)),
        },
        "relation_metrics": relation_metrics,
        "ablation": {
            "single_relation_results": ablation_rows,
            "negatively_exercised_relations": exercised,
            "no_negative_coverage": [name for name in RELATIONS if name not in exercised],
            "failure_patterns": dict(failure_patterns),
            "joint_remove_all_negatively_exercised": {
                "removed": exercised,
                "unauthorized_admissions": joint_admissions,
                "unauthorized_total": len(reference_stop),
                "rate": joint_admissions / len(reference_stop),
            },
            "independent_necessity": "NOT ESTABLISHED",
            "schema_claim": "Eight relations are a proposed auditable decomposition, not an empirically proven minimal basis.",
        },
        "error_count": len(errors),
    }

    write_csv(RESULTS / "comparison_by_case.csv", comparison)
    error_fields = list(comparison[0])
    write_csv(RESULTS / "error_analysis.csv", errors, error_fields)
    write_csv(RESULTS / "relation_metrics.csv", relation_rows)
    write_csv(RESULTS / "ablation_results.csv", ablation_rows)
    write_csv(RESULTS / "cofailure_patterns.csv", cofailure_rows)
    (RESULTS / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    summary = f"""# HF2007 Actual Experimental Results

- Reference/prediction vectors: {exact_count}/{n} exact matches ({pct(exact_count/n)}; Wilson 95% {pct(metrics['exact_vector_match']['wilson95'][0])}-{pct(metrics['exact_vector_match']['wilson95'][1])}).
- T0 outcome agreement: {outcome_count}/{n} ({pct(outcome_count/n)}; Wilson 95% {pct(metrics['t0_outcome_agreement']['wilson95'][0])}-{pct(metrics['t0_outcome_agreement']['wilson95'][1])}).
- Authorized controls: {len(reference_pass)-false_stops}/{len(reference_pass)} PASS; false-stop rate {false_stops}/{len(reference_pass)} ({pct(false_stops/len(reference_pass))}; Wilson 95% {pct(metrics['end_to_end']['false_stop_rate_wilson95'][0])}-{pct(metrics['end_to_end']['false_stop_rate_wilson95'][1])}).
- Tool-output transitions: {len(reference_stop)-false_admissions}/{len(reference_stop)} STOP_0/REVIEW; false-admission rate {false_admissions}/{len(reference_stop)} ({pct(false_admissions/len(reference_stop))}; Wilson 95% {pct(metrics['end_to_end']['false_admission_rate_wilson95'][0])}-{pct(metrics['end_to_end']['false_admission_rate_wilson95'][1])}).
- Negative coverage: {', '.join(exercised)}.
- No negative coverage: {', '.join(name for name in RELATIONS if name not in exercised)}.
- Observed reference vectors: {dict(Counter(row['relation_vector'] for row in refs))}.
- All five negatively exercised relations co-fail in every one of the 34 stopped transitions. Removing any single relation admits 0/34; jointly removing all five admits 34/34.
- Independent necessity: NOT ESTABLISHED.
- Claim: Eight relations are a proposed auditable decomposition, not an empirically proven minimal basis.
"""
    (RESULTS / "ACTUAL_RESULTS.md").write_text(summary, encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
