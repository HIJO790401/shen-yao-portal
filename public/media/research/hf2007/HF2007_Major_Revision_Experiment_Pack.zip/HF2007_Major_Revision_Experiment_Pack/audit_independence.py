#!/usr/bin/env python3
"""Audit file-level and input-field independence of the HF2007 extractor."""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "selected_raw_cases.jsonl"
EXTRACTOR = ROOT / "extractor" / "t0_extractor.py"
REPORT = ROOT / "results" / "independence_audit.json"

FORBIDDEN_SOURCE_TERMS = [
    "reference_annotations.csv", "reference_decisions.csv", "t0_reference_decision",
    "expected achievements", "reviewer desired outcome", "01110000", "11111111",
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    source = EXTRACTOR.read_text(encoding="utf-8").lower()
    source_hits = [term for term in FORBIDDEN_SOURCE_TERMS if term in source]
    raw_rows = [json.loads(line) for line in RAW.read_text(encoding="utf-8").splitlines() if line]
    forbidden_key_hits = []
    for row in raw_rows:
        for key in row:
            low = key.lower()
            if any(token in low for token in ["reference", "expected", "achievement", "attack_type", "ground_truth", "reviewer"]):
                forbidden_key_hits.append({"case_id": row.get("case_id"), "key": key})

    with tempfile.TemporaryDirectory(prefix="hf2007_extractor_isolation_") as temp:
        temp_path = Path(temp)
        isolated_extractor = temp_path / "t0_extractor.py"
        isolated_input = temp_path / "selected_raw_cases.jsonl"
        isolated_output = temp_path / "predicted_relations.csv"
        shutil.copy2(EXTRACTOR, isolated_extractor)
        shutil.copy2(RAW, isolated_input)
        completed = subprocess.run(
            [sys.executable, str(isolated_extractor), "--input", str(isolated_input), "--output", str(isolated_output)],
            cwd=temp_path, capture_output=True, text=True, check=False,
        )
        isolated_ok = completed.returncode == 0 and isolated_output.exists()
        isolated_output_sha256 = digest(isolated_output) if isolated_output.exists() else None

    report = {
        "status": "PASS" if not source_hits and not forbidden_key_hits and isolated_ok else "FAIL",
        "extractor_source_sha256": digest(EXTRACTOR),
        "raw_input_sha256": digest(RAW),
        "forbidden_source_term_hits": source_hits,
        "forbidden_raw_key_hits": forbidden_key_hits,
        "isolated_execution": {
            "reference_files_present": False,
            "return_code": completed.returncode,
            "output_created": isolated_ok,
            "output_sha256": isolated_output_sha256,
            "stderr": completed.stderr,
        },
        "note": "The isolated directory contained only the extractor and raw-only input; comparison and reference files were absent.",
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
