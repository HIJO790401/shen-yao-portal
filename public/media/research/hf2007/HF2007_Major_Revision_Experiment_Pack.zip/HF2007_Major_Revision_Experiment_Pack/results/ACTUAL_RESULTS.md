# HF2007 Actual Experimental Results

- Reference/prediction vectors: 51/51 exact matches (100.00%; Wilson 95% 93.00%-100.00%).
- T0 outcome agreement: 51/51 (100.00%; Wilson 95% 93.00%-100.00%).
- Authorized controls: 17/17 PASS; false-stop rate 0/17 (0.00%; Wilson 95% 0.00%-18.43%).
- Tool-output transitions: 34/34 STOP_0/REVIEW; false-admission rate 0/34 (0.00%; Wilson 95% 0.00%-10.15%).
- Negative coverage: definer_to_object, boundary_to_scope, gap_to_stop, output_to_authority, result_to_responsibility.
- No negative coverage: theory_to_domain, evidence_to_proposition, cause_to_conclusion.
- Observed reference vectors: {'11111111': 17, '01110000': 34}.
- All five negatively exercised relations co-fail in every one of the 34 stopped transitions. Removing any single relation admits 0/34; jointly removing all five admits 34/34.
- Independent necessity: NOT ESTABLISHED.
- Claim: Eight relations are a proposed auditable decomposition, not an empirically proven minimal basis.
